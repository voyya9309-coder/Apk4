package com.voyya.negocio;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.provider.Settings.Secure;
import android.webkit.GeolocationPermissions;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebResourceResponse;
import android.widget.EditText;
import java.io.ByteArrayInputStream;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    static final int REQ_FILE = 1, REQ_PERM = 2, REQ_BAT = 3;
    static final String HOST = "app.voyya.local", BASE = "https://" + HOST + "/";
    WebView web;
    ValueCallback<Uri[]> fileCb;
    GeolocationPermissions.Callback geoCb;
    String geoOrigin;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#141414"));
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return abrir(r.getUrl()); }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String path = u.getPath() == null || u.getPath().equals("/") ? "index.html" : u.getPath().substring(1);
                try {
                    String mime = path.endsWith(".html") ? "text/html" : path.endsWith(".js") ? "application/javascript"
                            : path.endsWith(".css") ? "text/css" : path.endsWith(".png") ? "image/png" : "application/octet-stream";
                    return new WebResourceResponse(mime, "UTF-8", getAssets().open(path));
                } catch (Exception ex) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) cb.invoke(origin, true, false);
                else { geoCb = cb; geoOrigin = origin; pedirPermisos(); }
            }
            @Override public boolean onJsAlert(WebView w, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int i) { r.confirm(); } }).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView w, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setCancelable(false)
                    .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int i) { r.confirm(); } })
                    .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int i) { r.cancel(); } }).show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView w, String url, String msg, String def, final JsPromptResult r) {
                final EditText et = new EditText(MainActivity.this); et.setText(def);
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(et).setCancelable(false)
                    .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int i) { r.confirm(et.getText().toString()); } })
                    .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int i) { r.cancel(); } }).show();
                return true;
            }
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), REQ_FILE); }
                catch (Exception e) { fileCb = null; return false; }
                return true;
            }
        });
        web.loadUrl(BASE + "index.html");
        pedirPermisos();
    }

    boolean abrir(Uri u) {
        String sc = u.getScheme() == null ? "" : u.getScheme(), host = u.getHost() == null ? "" : u.getHost();
        if (sc.equals("about") || sc.equals("data") || sc.equals("blob")) return false;
        if ((sc.equals("https") || sc.equals("http")) && host.equals(HOST)) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
        return true;
    }

    void pedirPermisos() {
        List<String> l = new ArrayList<>();
        for (String p : new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION})
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) l.add(p);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            l.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!l.isEmpty()) requestPermissions(l.toArray(new String[0]), REQ_PERM); else pedirBateria();
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req != REQ_PERM) return;
        boolean ubic = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (geoCb != null) { geoCb.invoke(geoOrigin, ubic, false); geoCb = null; }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Sin permiso de notificaciones no sonarán los pedidos nuevos", Toast.LENGTH_LONG).show();
        pedirBateria();
    }

    void pedirBateria() {
        SharedPreferences sp = getSharedPreferences("voyya", MODE_PRIVATE);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName()) && !sp.getBoolean("bat", false)) {
            sp.edit().putBoolean("bat", true).apply();
            try { startActivityForResult(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())), REQ_BAT); }
            catch (Exception e) { }
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    @Override protected void onResume() {
        super.onResume();
        try {   // al abrir la app se quitan los avisos viejos de pedidos
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            for (StatusBarNotification n : nm.getActiveNotifications()) if (n.getId() != PedidoService.FG_ID) nm.cancel(n.getId());
        } catch (Exception e) { }
    }

    @Override public void onBackPressed() { moveTaskToBack(true); }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }

    class Bridge {
        @JavascriptInterface public void setSession(String url, String key, String uid) {
            getSharedPreferences("voyya", MODE_PRIVATE).edit().putString("url", url).putString("key", key).putString("uid", uid).apply();
            try {
                Intent i = new Intent(MainActivity.this, PedidoService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            } catch (Exception e) { }
        }
        @JavascriptInterface public void clearSession() {
            getSharedPreferences("voyya", MODE_PRIVATE).edit().remove("url").remove("key").remove("uid").remove("seen").remove("pushlast").apply();
            stopService(new Intent(MainActivity.this, PedidoService.class));
        }
        @JavascriptInterface public String deviceId() { return Secure.getString(getContentResolver(), Secure.ANDROID_ID); }
        @JavascriptInterface public void permisos() { runOnUiThread(new Runnable() { public void run() { pedirPermisos(); } }); }
    }
}
