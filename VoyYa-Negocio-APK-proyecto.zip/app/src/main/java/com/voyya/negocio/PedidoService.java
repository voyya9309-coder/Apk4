package com.voyya.negocio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/** Servicio en primer plano: revisa cada 10 s si hay pedidos nuevos y avisa con sonido aunque la app esté cerrada. */
public class PedidoService extends Service {
    static final String CH_FG = "fg_v1", CH_PED = "pedidos_v1", CH_PUSH = "avisos_v1";
    static final int FG_ID = 1;
    static final long[] VIB = {0, 400, 200, 400, 200, 400};
    volatile boolean run = false;
    Thread th;
    PowerManager.WakeLock wl;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() { super.onCreate(); canales(); }

    Uri sonido() { return Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.pedido_nuevo); }

    void canales() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel fg = new NotificationChannel(CH_FG, "Servicio de pedidos", NotificationManager.IMPORTANCE_LOW);
        fg.setShowBadge(false);
        nm.createNotificationChannel(fg);
        NotificationChannel pd = new NotificationChannel(CH_PED, "Pedidos nuevos", NotificationManager.IMPORTANCE_HIGH);
        pd.setSound(sonido(), new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        pd.enableVibration(true);
        pd.setVibrationPattern(VIB);
        pd.enableLights(true);
        pd.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(pd);
        // Avisos del administrador: usan el sonido de notificación que tenga el teléfono
        NotificationChannel av = new NotificationChannel(CH_PUSH, "Avisos de VoyYa", NotificationManager.IMPORTANCE_HIGH);
        av.enableVibration(true);
        av.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(av);
    }

    PendingIntent abrirApp(int code) {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    Notification base() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH_FG) : new Notification.Builder(this);
        return b.setSmallIcon(R.drawable.ic_stat).setContentTitle("VoyYa Negocio activo")
                .setContentText("Esperando pedidos nuevos…").setOngoing(true).setContentIntent(abrirApp(0)).build();
    }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(FG_ID, base(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(FG_ID, base());
        } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }
        SharedPreferences sp = getSharedPreferences("voyya", MODE_PRIVATE);
        if (sp.getString("uid", "").isEmpty()) { stopSelf(); return START_NOT_STICKY; }
        if (!run) {
            run = true;
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voyya:pedidos");
            wl.setReferenceCounted(false);
            wl.acquire();
            th = new Thread(new Runnable() { public void run() { loop(); } }, "poll-pedidos");
            th.start();
        }
        return START_STICKY;
    }

    void loop() {
        while (run) {
            try { poll(); } catch (Exception e) { }
            try { pollPush(); } catch (Exception e) { }
            try { Thread.sleep(10000); } catch (InterruptedException e) { break; }
        }
    }

    String http(String q, String key) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(q).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("apikey", key);
        if (!key.startsWith("sb_")) c.setRequestProperty("Authorization", "Bearer " + key);
        if (c.getResponseCode() != 200) { c.disconnect(); return null; }
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        try (InputStream in = c.getInputStream()) { byte[] buf = new byte[4096]; int n; while ((n = in.read(buf)) > 0) o.write(buf, 0, n); }
        c.disconnect();
        return new String(o.toByteArray(), "UTF-8");
    }

    void poll() throws Exception {
        SharedPreferences sp = getSharedPreferences("voyya", MODE_PRIVATE);
        String url = sp.getString("url", ""), key = sp.getString("key", ""), uid = sp.getString("uid", "");
        if (url.isEmpty() || uid.isEmpty()) return;
        String body = http(url + "/rest/v1/pedidos?select=id,cliente_nombre,total,negocios!inner(dueno_id)&negocios.dueno_id=eq." + uid
                + "&estado=eq.pendiente&order=creado.desc&limit=30", key);
        if (body == null) return;
        JSONArray a = new JSONArray(body);
        Set<String> vistos = new HashSet<String>(sp.getStringSet("seen", new HashSet<String>()));
        Set<String> ahora = new HashSet<String>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject p = a.getJSONObject(i);
            String id = p.getString("id");
            ahora.add(id);
            if (!vistos.contains(id)) avisar(id, p.optString("cliente_nombre", "Cliente"), p.opt("total"));
        }
        sp.edit().putStringSet("seen", ahora).apply();
    }

    static String str(JSONObject o, String k) { return o.isNull(k) ? "" : o.optString(k, ""); }

    /** Avisos enviados por el administrador (texto, foto o audio) a todos o solo a este usuario. */
    void pollPush() throws Exception {
        SharedPreferences sp = getSharedPreferences("voyya", MODE_PRIVATE);
        String url = sp.getString("url", ""), key = sp.getString("key", ""), uid = sp.getString("uid", "");
        if (url.isEmpty() || uid.isEmpty()) return;
        String last = sp.getString("pushlast", "");
        if (last.isEmpty()) {   // primera vez: no se avisa lo viejo
            String b0 = http(url + "/rest/v1/push?select=creado&order=creado.desc&limit=1", key);
            if (b0 == null) return;
            JSONArray a0 = new JSONArray(b0);
            sp.edit().putString("pushlast", a0.length() > 0 ? a0.getJSONObject(0).getString("creado") : "1970-01-01T00:00:00+00:00").apply();
            return;
        }
        String q = url + "/rest/v1/push?select=id,titulo,mensaje,audio_url,foto_url,creado&creado=gt." + URLEncoder.encode(last, "UTF-8")
                + "&or=" + URLEncoder.encode("(usuarios.is.null,usuarios.cs.{" + uid + "})", "UTF-8") + "&order=creado.asc&limit=20";
        String body = http(q, key);
        if (body == null) return;
        JSONArray a = new JSONArray(body);
        for (int i = 0; i < a.length(); i++) {
            JSONObject p = a.getJSONObject(i);
            mostrarPush(p);
            last = p.getString("creado");
            sp.edit().putString("pushlast", last).apply();
        }
    }

    Bitmap bitmap(String u) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            try (InputStream in = c.getInputStream()) { return BitmapFactory.decodeStream(in); }
        } catch (Exception e) { return null; }
    }

    void mostrarPush(JSONObject p) {
        String t = str(p, "titulo"), m = str(p, "mensaje"), foto = str(p, "foto_url"), audio = str(p, "audio_url");
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH_PUSH)
                : new Notification.Builder(this).setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        b.setSmallIcon(R.drawable.ic_stat).setContentTitle(t.isEmpty() ? "VoyYa" : t)
                .setContentText(m + (audio.isEmpty() ? "" : " 🔊")).setStyle(new Notification.BigTextStyle().bigText(m))
                .setAutoCancel(true).setContentIntent(abrirApp(str(p, "id").hashCode()))
                .setCategory(Notification.CATEGORY_MESSAGE).setVisibility(Notification.VISIBILITY_PUBLIC);
        if (!foto.isEmpty()) {
            Bitmap bm = bitmap(foto);
            if (bm != null) b.setLargeIcon(bm).setStyle(new Notification.BigPictureStyle().bigPicture(bm).setSummaryText(m));
        }
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(str(p, "id").hashCode(), b.build());
        if (!audio.isEmpty()) sonarAudio(audio);
    }

    void sonarAudio(String url) {
        try {
            final MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            mp.setDataSource(url);
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { public void onPrepared(MediaPlayer x) { x.start(); } });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { public void onCompletion(MediaPlayer x) { x.release(); } });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() { public boolean onError(MediaPlayer x, int w, int e) { x.release(); return true; } });
            mp.prepareAsync();
        } catch (Exception e) { }
    }

    void avisar(String id, String cliente, Object total) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH_PED)
                : new Notification.Builder(this).setPriority(Notification.PRIORITY_MAX).setSound(sonido()).setVibrate(VIB);
        b.setSmallIcon(R.drawable.ic_stat).setContentTitle("🛵 ¡Nuevo pedido!")
                .setContentText(cliente + (total != null && !JSONObject.NULL.equals(total) ? " · " + total + " CUP" : ""))
                .setAutoCancel(true).setContentIntent(abrirApp(id.hashCode()))
                .setCategory(Notification.CATEGORY_MESSAGE).setVisibility(Notification.VISIBILITY_PUBLIC);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(id.hashCode(), b.build());
    }

    @Override public void onDestroy() {
        run = false;
        if (th != null) th.interrupt();
        if (wl != null && wl.isHeld()) wl.release();
        super.onDestroy();
    }
}
