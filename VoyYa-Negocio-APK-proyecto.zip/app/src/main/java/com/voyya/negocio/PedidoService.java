package com.voyya.negocio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/** Servicio en primer plano: revisa cada 10 s si hay pedidos nuevos y avisa con sonido aunque la app esté cerrada. */
public class PedidoService extends Service {
    static final String CH_FG = "fg_v1", CH_PED = "pedidos_v1";
    static final int FG_ID = 1;
    static final long[] VIB = {0, 400, 200, 400, 200, 400};
    volatile boolean run = false;
    Thread th;
    PowerManager.WakeLock wl;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() { super.onCreate(); canales(); }

    Uri sonido() { return Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.pedido_nuevo); }

    void canales() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel fg = new NotificationChannel(CH_FG, "Servicio de pedidos", NotificationManager.IMPORTANCE_LOW);
        fg.setShowBadge(false);
        nm.createNotificationChannel(fg);
        NotificationChannel pd = new NotificationChannel(CH_PED, "Pedidos nuevos", NotificationManager.IMPORTANCE_HIGH);
        pd.setSound(sonido(), new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        pd.enableVibration(true);
        pd.setVibrationPattern(VIB);
        pd.enableLights(true);
        pd.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(pd);
    }

    PendingIntent abrirApp(int code) {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    Notification base() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH_FG) : new Notification.Builder(this);
        return b.setSmallIcon(R.drawable.ic_stat).setContentTitle("VoyYa Negocio activo")
                .setContentText("Esperando pedidos nuevos…").setOngoing(true).setContentIntent(abrirApp(0)).build();
    }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(FG_ID, base(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(FG_ID, base());
        } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }
        SharedPreferences sp = getSharedPreferences("voyya", MODE_PRIVATE);
        if (sp.getString("uid", "").isEmpty()) { stopSelf(); return START_NOT_STICKY; }
        if (!run) {
            run = true;
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voyya:pedidos");
            wl.setReferenceCounted(false);
            wl.acquire();
            th = new Thread(new Runnable() { public void run() { loop(); } }, "poll-pedidos");
            th.start();
        }
        return START_STICKY;
    }

    void loop() {
        while (run) {
            try { poll(); } catch (Exception e) { }
            try { Thread.sleep(10000); } catch (InterruptedException e) { break; }
        }
    }

    void poll() throws Exception {
        SharedPreferences sp = getSharedPreferences("voyya", MODE_PRIVATE);
        String url = sp.getString("url", ""), key = sp.getString("key", ""), uid = sp.getString("uid", "");
        if (url.isEmpty() || uid.isEmpty()) return;
        String q = url + "/rest/v1/pedidos?select=id,cliente_nombre,total,negocios!inner(dueno_id)&negocios.dueno_id=eq." + uid
                + "&estado=eq.pendiente&order=creado.desc&limit=30";
        HttpURLConnection c = (HttpURLConnection) new URL(q).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("apikey", key);
        if (!key.startsWith("sb_")) c.setRequestProperty("Authorization", "Bearer " + key);
        if (c.getResponseCode() != 200) { c.disconnect(); return; }
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        try (InputStream in = c.getInputStream()) { byte[] buf = new byte[4096]; int n; while ((n = in.read(buf)) > 0) o.write(buf, 0, n); }
        c.disconnect();
        JSONArray a = new JSONArray(new String(o.toByteArray(), "UTF-8"));
        Set<String> vistos = new HashSet<String>(sp.getStringSet("seen", new HashSet<String>()));
        Set<String> ahora = new HashSet<String>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject p = a.getJSONObject(i);
            String id = p.getString("id");
            ahora.add(id);
            if (!vistos.contains(id)) avisar(id, p.optString("cliente_nombre", "Cliente"), p.opt("total"));
        }
        sp.edit().putStringSet("seen", ahora).apply();
    }

    void avisar(String id, String cliente, Object total) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH_PED)
                : new Notification.Builder(this).setPriority(Notification.PRIORITY_MAX).setSound(sonido()).setVibrate(VIB);
        b.setSmallIcon(R.drawable.ic_stat).setContentTitle("🛵 ¡Nuevo pedido!")
                .setContentText(cliente + (total != null && !JSONObject.NULL.equals(total) ? " · " + total + " CUP" : ""))
                .setAutoCancel(true).setContentIntent(abrirApp(id.hashCode()))
                .setCategory(Notification.CATEGORY_MESSAGE).setVisibility(Notification.VISIBILITY_PUBLIC);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(id.hashCode(), b.build());
    }

    @Override public void onDestroy() {
        run = false;
        if (th != null) th.interrupt();
        if (wl != null && wl.isHeld()) wl.release();
        super.onDestroy();
    }
}
