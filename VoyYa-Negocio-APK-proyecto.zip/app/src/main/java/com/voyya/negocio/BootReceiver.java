package com.voyya.negocio;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Al encender el teléfono (o actualizar la app) vuelve a activar los avisos si ya habías iniciado sesión. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        if (c.getSharedPreferences("voyya", Context.MODE_PRIVATE).getString("uid", "").isEmpty()) return;
        try {
            Intent s = new Intent(c, PedidoService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s); else c.startService(s);
        } catch (Exception e) { }
    }
}
