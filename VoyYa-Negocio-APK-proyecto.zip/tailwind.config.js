module.exports = {
  content: ['./app/src/main/assets/index.html'],
  theme: { extend: { colors: { v: 'var(--v)', vt: 'var(--vt)', s: 'var(--s)', ink: 'var(--ink)', hd: 'var(--hd)' } } },
  plugins: []
};
