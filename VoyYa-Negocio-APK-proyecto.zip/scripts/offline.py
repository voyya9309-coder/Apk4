# Cambia las librerías de internet (CDN) por archivos locales dentro de la APK, solo si se descargaron bien.
import os
A = 'app/src/main/assets'
p = A + '/index.html'
s = open(p, encoding='utf-8').read()
def ok(f, mn): return os.path.exists(A + '/' + f) and os.path.getsize(A + '/' + f) > mn
CAMBIOS = [
    ('<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.58.0/dist/umd/supabase.min.js"></script>', '<script src="supabase.js"></script>', 'supabase.js', 50000),
    ('<script src="https://cdn.jsdelivr.net/npm/lucide@0.460.0/dist/umd/lucide.min.js"></script>', '<script src="lucide.js"></script>', 'lucide.js', 50000),
    ('<script src="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js"></script>', '<script src="leaflet.js"></script>', 'leaflet.js', 50000),
    ('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css">', '<link rel="stylesheet" href="leaflet.css">', 'leaflet.css', 2000),
    ('<script src="https://cdn.tailwindcss.com/3.4.17"></script>', '<link rel="stylesheet" href="tw.css">', 'tw.css', 8000),
]
for viejo, nuevo, f, mn in CAMBIOS:
    if ok(f, mn) and viejo in s:
        s = s.replace(viejo, nuevo); print('local:', f)
        if f == 'tw.css':
            i = s.find('<script>tailwind.config='); j = s.find('</script>', i)
            if i >= 0: s = s[:i] + s[j + 9:]
    else:
        print('se queda en internet:', f)
open(p, 'w', encoding='utf-8').write(s)
