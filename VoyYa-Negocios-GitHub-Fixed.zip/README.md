# VoyYa Negocios — proyecto Android

## Compilar en GitHub
1. Descomprime el ZIP y sube SU CONTENIDO a la raíz de un repositorio, incluyendo `.github/workflows/android.yml` (no subas solo el ZIP).
2. Abre Actions > Compilar APK negocios > Run workflow. También compila al enviar cambios a main/master.
3. Descarga el artifact VoyYa-Negocios-APK: contiene una APK debug instalable. No es una release firmada para tiendas. Para actualizaciones estables necesitas firma propia.

Build: Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, SDK 35. El workflow descarga dependencias. No necesita google-services.json ni Firebase. Local: instala esas herramientas y ejecuta gradle :app:assembleDebug. No incluye wrapper binario.

## Uso
Se conserva la pantalla de carga e imagen originales y una nueva portada exclusiva para negocios; navegación Inicio / Mi negocio / Soporte. Registro, productos y pedidos reutilizan el HTML original y la misma base de datos. No se ejecuta SQL ni se modifica la base al compilar. El código legado conserva funciones auxiliares de otros roles, pero sus accesos y rutas están bloqueados en esta distribución. Esta restricción de interfaz NO sustituye autorización en servidor.

Inicia sesión con una cuenta de negocio aprobada. En Inicio toca Activar avisos fuera de la app, y permite notificaciones. Se inicia un servicio visible con aviso persistente. Se mantiene conexión WebSocket Supabase Realtime a INSERT de pedidos filtrada por negocio_id; cada 25 segundos se intenta recuperar pedidos perdidos, con deduplicación persistente. Tu MP3 está en res/raw/pedido_negocio.mp3 y es el sonido del canal Pedidos del negocio. Tocar un aviso abre la aplicación. Pausar avisos o salir detiene el servicio.

## Requisitos y límites IMPORTANTES
- Requiere Internet, esquema original operativo y la tabla pedidos en la publicación supabase_realtime. No hace falta un nuevo backend para esta variante compatible.
- Debes activar monitoreo manualmente después de abrir sesión. No arranca al reiniciar teléfono. No garantiza recepción después de forzar detención, terminar el servicio desde Android o restricciones del fabricante. En reposo/Doze puede haber retrasos. No implementa FCM.
- Android controla canal, volumen, No molestar y permisos. El MP3 no puede eludirlos. Si cambias el sonido en el código, cambia también el identificador del canal o reinstala para aplicar un canal nuevo.
- Se declara foregroundServiceType specialUse por monitoreo explícito del comercio. No implica aprobación de Google Play; una publicación debe justificarlo y pasar sus políticas.
- El HTML usa CDNs externos y requiere conexión. No es una versión offline.
- La primera activación escucha pedidos a partir de ese momento; pedidos anteriores siguen en el panel. Recuperación paginada básica de 100 filas: no garantiza recuperar colas superiores a 100 pedidos con idéntica fecha de creación.

## Seguridad heredada: NO LISTO PARA PRODUCCIÓN
El archivo original autentica mediante consultas a usuarios con clave y contiene SQL con políticas anon abiertas. Se conserva esa compatibilidad; NO se ejecuta ese SQL. Una clave pública de Supabase no es secreta, pero políticas abiertas y claves de usuario en texto son inseguras. No uses este proyecto con datos personales reales hasta migrar a Supabase Auth, RLS por negocio y autorización verificada en servidor. El filtro negocio_id de la app NO es un control de acceso. El WebView conserva CDNs externos: audita o empaqueta esos recursos antes de producción.

Para push de producción sin depender de una conexión permanente: migrar autenticación y añadir FCM más una función servidor/webhook con credenciales fuera de la APK. Esta entrega no afirma que ese servicio exista.

## Prueba manual necesaria
No se ha compilado ni probado en un Android desde este entorno. El CI es quien verificará la compilación.
1. Ejecuta workflow e instala APK.
2. Accede al negocio aprobado y activa avisos; acepta permiso.
3. Minimiza la app y crea un pedido real desde la aplicación cliente para ese negocio.
4. Comprueba aviso, MP3 y apertura al tocar; repite con pantalla bloqueada.
5. Prueba desconexión/reconexión, otro negocio (no debe avisar), salida y permiso denegado.
6. Comprueba alta de producto, foto, ubicación (si se deniega permiso, vuelve a pulsar después de concederlo) y cambios de estado.
