package com.voyya.negocio
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.*
import androidx.core.app.NotificationCompat
import okhttp3.*
import org.json.*
import java.util.concurrent.TimeUnit

class RtService : Service() {
  private val URL = "https://efxosdwucdkvveymvuxq.supabase.co"
  private val KEY = "sb_publishable_x5rb1Xpe8-GM074IfvNRqg_tvWEm1RA"
  private val http = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
  private val h = Handler(Looper.getMainLooper())
  private var ws: WebSocket? = null
  private var neg = ""
  private var ref = 1
  override fun onBind(i: Intent?): IBinder? = null

  override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
    canales()
    val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    val n = NotificationCompat.Builder(this, "fg").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("VoyYa Negocio")
      .setContentText("Escuchando pedidos y avisos").setContentIntent(pi).setOngoing(true).build()
    if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
    if (ws == null) conectar()
    return START_STICKY
  }
  private fun canales() {
    val nm = getSystemService(NotificationManager::class.java)
    val aa = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build()
    nm.createNotificationChannel(NotificationChannel("fg", "Servicio activo", NotificationManager.IMPORTANCE_LOW))
    nm.createNotificationChannel(NotificationChannel("pedidos", "Pedidos nuevos", NotificationManager.IMPORTANCE_HIGH).apply {
      setSound(Uri.parse("android.resource://$packageName/${R.raw.pedido}"), aa); enableVibration(true); vibrationPattern = longArrayOf(0, 400, 200, 400) })
    nm.createNotificationChannel(NotificationChannel("avisos", "Avisos", NotificationManager.IMPORTANCE_HIGH).apply {
      setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), aa) })
  }
  private fun conectar() {
    ws = null
    Thread {
      try {
        val uid = getSharedPreferences("v", 0).getString("uid", "") ?: ""
        if (uid.isNotEmpty()) {
          val r = http.newCall(Request.Builder().url("$URL/rest/v1/negocios?dueno_id=eq.$uid&select=id").header("apikey", KEY).build()).execute()
          val a = JSONArray(r.body?.string() ?: "[]"); if (a.length() > 0) neg = a.getJSONObject(0).getString("id")
        }
      } catch (_: Exception) {}
      h.post { abrir() }
    }.start()
  }
  private fun s(o: JSONObject, k: String) = if (o.isNull(k)) "" else o.optString(k)
  private fun abrir() {
    val mio = object : WebSocketListener() {
      override fun onOpen(w: WebSocket, r: Response) {
        w.send("""{"topic":"realtime:voyya","event":"phx_join","payload":{"config":{"postgres_changes":[{"event":"INSERT","schema":"public","table":"pedidos"},{"event":"INSERT","schema":"public","table":"avisos"}]}},"ref":"${ref++}"}""")
        latido(w) }
      override fun onMessage(w: WebSocket, t: String) { try {
        val j = JSONObject(t); if (j.optString("event") != "postgres_changes") return
        val d = j.getJSONObject("payload").getJSONObject("data"); val rec = d.getJSONObject("record")
        when (d.getString("table")) {
          "pedidos" -> if (neg.isNotEmpty() && s(rec, "negocio_id") == neg) avisar("pedidos", "🛵 ¡Nuevo pedido!", "De ${s(rec, "cliente_nombre").ifEmpty { "un cliente" }} · ${s(rec, "total")} CUP")
          "avisos" -> avisar("avisos", s(rec, "titulo").ifEmpty { "📢 Aviso" }, s(rec, "mensaje")) }
      } catch (_: Exception) {} }
      override fun onFailure(w: WebSocket, t: Throwable, r: Response?) { caido(w) }
      override fun onClosed(w: WebSocket, c: Int, r: String) { caido(w) }
    }
    ws = http.newWebSocket(Request.Builder().url(URL.replace("https", "wss") + "/realtime/v1/websocket?apikey=$KEY&vsn=1.0.0").build(), mio)
  }
  private fun latido(w: WebSocket) { h.postDelayed({ if (ws === w) { w.send("""{"topic":"phoenix","event":"heartbeat","payload":{},"ref":"${ref++}"}"""); latido(w) } }, 25000) }
  private fun caido(w: WebSocket) { if (ws !== w) return; ws = null; h.postDelayed({ conectar() }, 5000) }
  private fun avisar(canal: String, titulo: String, texto: String) {
    val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    val n = NotificationCompat.Builder(this, canal).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(titulo).setContentText(texto)
      .setStyle(NotificationCompat.BigTextStyle().bigText(texto)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi).build()
    getSystemService(NotificationManager::class.java).notify(System.currentTimeMillis().toInt(), n)
  }
  override fun onDestroy() { ws?.cancel(); ws = null; super.onDestroy() }
}
