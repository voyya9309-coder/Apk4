package com.voyya.negocio
import android.content.*
class BootReceiver: BroadcastReceiver() {
  override fun onReceive(c: Context, i: Intent) { if (c.getSharedPreferences("v",0).getString("uid","").isNullOrEmpty()) return
    c.startForegroundService(Intent(c, RtService::class.java)) }
}
