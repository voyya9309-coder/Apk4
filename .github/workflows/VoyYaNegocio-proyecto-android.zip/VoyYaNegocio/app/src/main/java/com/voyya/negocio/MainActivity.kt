package com.voyya.negocio
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.webkit.*

class MainActivity : Activity() {
  private lateinit var wv: WebView
  private var fcb: ValueCallback<Array<Uri>>? = null
  inner class Puente { @JavascriptInterface fun setUser(id: String) {
      if (getSharedPreferences("v",0).getString("uid","") == id) return
      getSharedPreferences("v",0).edit().putString("uid", id).apply(); arrancar() } }
  private fun arrancar() { startForegroundService(Intent(this, RtService::class.java)) }
  override fun onCreate(b: Bundle?) { super.onCreate(b)
    requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS, android.Manifest.permission.ACCESS_FINE_LOCATION), 1)
    wv = WebView(this); setContentView(wv)
    wv.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false }
    wv.addJavascriptInterface(Puente(), "Android"); wv.webViewClient = WebViewClient()
    wv.webChromeClient = object : WebChromeClient() {
      override fun onGeolocationPermissionsShowPrompt(o: String, cb: GeolocationPermissions.Callback) { cb.invoke(o, true, false) }
      override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean { fcb?.onReceiveValue(null); fcb = cb; startActivityForResult(p.createIntent(), 7); return true } }
    wv.loadUrl("file:///android_asset/index.html")
    if (!getSharedPreferences("v",0).getString("uid","").isNullOrEmpty()) arrancar()
    if (!(getSystemService(PowerManager::class.java)).isIgnoringBatteryOptimizations(packageName))
      try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
  }
  override fun onActivityResult(rq: Int, rs: Int, d: Intent?) { if (rq == 7) { fcb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d)); fcb = null } }
  @Deprecated("Deprecated") override fun onBackPressed() { if (wv.canGoBack()) wv.goBack() else super.onBackPressed() }
}
