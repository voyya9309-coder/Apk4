# ¡VoyYa! Negocios (APK)

Proyecto Android (WebView + servicio de avisos). Sube el ZIP a GitHub y el workflow lo compila.
