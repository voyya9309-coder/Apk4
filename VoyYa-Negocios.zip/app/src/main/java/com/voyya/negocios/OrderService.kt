package com.voyya.negocios

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Servicio en primer plano: mantiene abierta la conexión en tiempo real con Supabase
 * y lanza una notificación con el audio Dueño_de_negocio.mp3 cuando llega un pedido nuevo a TU negocio.
 * Funciona con la app cerrada y con la pantalla apagada (enciende la pantalla unos segundos al llegar un pedido).
 */
class OrderService : Service() {

    companion object {
        const val CH_SERVICE = "servicio_v1"
        const val CH_ORDERS = "pedidos_v1"
        const val NOTIF_FG = 1

        @Volatile
        var running = false

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, OrderService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, OrderService::class.java))
            } catch (_: Exception) {
            }
        }

        fun createChannels(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val fg = NotificationChannel(CH_SERVICE, "Conexión de pedidos", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Mantiene la app lista para avisarte de pedidos nuevos"
                setShowBadge(false)
            }
            nm.createNotificationChannel(fg)

            val sound = Uri.parse("android.resource://${ctx.packageName}/${R.raw.dueno_negocio}")
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val orders = NotificationChannel(CH_ORDERS, "Pedidos nuevos", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Aviso con sonido cuando llega un pedido a tu negocio"
                setSound(sound, attrs)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400, 200, 600)
                enableLights(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(orders)
        }
    }

    // Cliente para el WebSocket (sin límite de lectura) y otro para peticiones REST (15 s)
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)
        .build()
    private val rest = http.newBuilder().readTimeout(15, TimeUnit.SECONDS).build()

    private val exec = Executors.newSingleThreadScheduledExecutor()
    private var pollTask: ScheduledFuture<*>? = null
    private var hbTask: ScheduledFuture<*>? = null
    private var socket: WebSocket? = null
    private var gen = 0
    private var retry = 0
    private var hbRef = 100
    private var currentUser: String? = null
    private var wl: PowerManager.WakeLock? = null

    @Volatile
    private var lastMsg = 0L

    @Volatile
    private var negocioId: String? = null

    private val notified = LinkedHashSet<String>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val fg = NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("¡VoyYa! Negocios")
            .setContentText("Conectado: te avisaremos de los pedidos nuevos")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent(0))
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_FG, fg, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_FG, fg)
        }

        val uid = Prefs.userId(this)
        if (uid == null) {
            shutdown()
            return START_NOT_STICKY
        }
        if (!running || uid != currentUser) {
            currentUser = uid
            running = true
            startWork()
        }
        return START_STICKY
    }

    private fun startWork() {
        synchronized(notified) { notified.clear() }
        negocioId = null
        if (wl == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voyya:pedidos").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
        pollTask?.cancel(false)
        hbTask?.cancel(false)
        post { connect() }
        try {
            pollTask = exec.scheduleWithFixedDelay({ safe { poll() } }, 5, 30, TimeUnit.SECONDS)
            hbTask = exec.scheduleWithFixedDelay({ safe { heartbeat() } }, 25, 25, TimeUnit.SECONDS)
        } catch (_: RejectedExecutionException) {
        }
    }

    /** Ejecuta en el hilo del servicio; si el servicio ya se apagó, ignora (evita que la app se cierre). */
    private fun post(block: () -> Unit) {
        try {
            exec.execute {
                try {
                    block()
                } catch (_: Throwable) {
                }
            }
        } catch (_: RejectedExecutionException) {
        }
    }

    private inline fun safe(block: () -> Unit) {
        try {
            block()
        } catch (_: Exception) {
        }
    }

    /* ---------------- Conexión en tiempo real (protocolo Phoenix de Supabase Realtime) ---------------- */

    private fun connect() {
        if (!running) return
        val url = Prefs.url(this) ?: return
        val key = Prefs.key(this) ?: return
        socket?.cancel()
        val myGen = ++gen
        val host = url.removePrefix("https://").trimEnd('/')
        val req = Request.Builder()
            .url("wss://$host/realtime/v1/websocket?apikey=$key&vsn=1.0.0")
            .build()
        lastMsg = System.currentTimeMillis()
        socket = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                post {
                    if (myGen != gen) return@post
                    retry = 0
                    lastMsg = System.currentTimeMillis()
                    webSocket.send(joinMessage(key))
                    safe { poll() } // averigua tu negocio y recupera lo que se haya perdido sin conexión
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                post { if (myGen == gen) safe { onWsMessage(text) } }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                post { if (myGen == gen) scheduleReconnect() }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                post { if (myGen == gen) scheduleReconnect() }
            }
        })
    }

    private fun scheduleReconnect() {
        if (!running) return
        gen++ // invalida eventos de la conexión anterior
        val delay = minOf(30L, 1L shl minOf(retry, 5))
        retry++
        try {
            exec.schedule({ safe { connect() } }, delay, TimeUnit.SECONDS)
        } catch (_: RejectedExecutionException) {
        }
    }

    private fun joinMessage(key: String): String {
        val change = JSONObject().put("event", "*").put("schema", "public").put("table", "pedidos")
        val config = JSONObject()
            .put("broadcast", JSONObject().put("ack", false).put("self", false))
            .put("presence", JSONObject().put("key", ""))
            .put("postgres_changes", JSONArray().put(change))
            .put("private", false)
        return JSONObject()
            .put("topic", "realtime:voyya-negocios")
            .put("event", "phx_join")
            .put("payload", JSONObject().put("config", config).put("access_token", key))
            .put("ref", "1")
            .put("join_ref", "1")
            .toString()
    }

    private fun heartbeat() {
        socket?.send(
            JSONObject()
                .put("topic", "phoenix")
                .put("event", "heartbeat")
                .put("payload", JSONObject())
                .put("ref", (hbRef++).toString())
                .toString()
        )
    }

    private fun onWsMessage(text: String) {
        lastMsg = System.currentTimeMillis()
        val j = JSONObject(text)
        when (j.optString("event")) {
            "postgres_changes" -> {
                val data = j.optJSONObject("payload")?.optJSONObject("data") ?: return
                onChange(data)
            }
            "phx_error", "phx_close" -> {
                socket?.cancel()
                scheduleReconnect()
            }
        }
    }

    private fun onChange(data: JSONObject) {
        val rec = data.optJSONObject("record") ?: return
        val id = rec.optString("id")
        if (id.isEmpty()) return
        val mio = negocioId ?: return
        if (rec.optString("negocio_id") != mio) return // pedido de otro negocio
        if (rec.optString("estado") == "pendiente") {
            consider(id, rec)
        } else {
            // Ya fue aceptado, rechazado o cancelado: quita su aviso
            NotificationManagerCompat.from(this).cancel(id.hashCode())
        }
    }

    /* ---------------- Peticiones REST ---------------- */

    private fun get(path: String): String? {
        val url = Prefs.url(this) ?: return null
        val key = Prefs.key(this) ?: return null
        val req = Request.Builder()
            .url("$url/rest/v1/$path")
            .header("apikey", key)
            .header("Authorization", "Bearer $key")
            .build()
        return try {
            rest.newCall(req).execute().use { if (it.isSuccessful) it.body?.string() else null }
        } catch (_: Exception) {
            null
        }
    }

    private fun poll() {
        if (!running) return
        val uid = Prefs.userId(this) ?: return

        // Si no llega nada del servidor en más de 75 s, la conexión está muerta: reconectar
        if (System.currentTimeMillis() - lastMsg > 75_000) {
            socket?.cancel()
            scheduleReconnect()
        }

        // 1) Estado de la cuenta (baneo / eliminada)
        val ub = get("usuarios?id=eq.$uid&select=baneado")
        if (ub != null) {
            val a = try { JSONArray(ub) } catch (_: Exception) { null }
            if (a != null) {
                if (a.length() == 0 || a.getJSONObject(0).optBoolean("baneado", false)) {
                    Prefs.clear(this)
                    shutdown()
                    return
                }
            }
        }

        // 2) Cuál es el negocio de este usuario
        val nb = get("negocios?dueno_id=eq.$uid&select=id")
        if (nb != null) {
            val a = try { JSONArray(nb) } catch (_: Exception) { null }
            if (a != null && a.length() > 0) negocioId = a.getJSONObject(0).optString("id")
        }
        val nid = negocioId ?: return

        // 3) Pedidos pendientes recientes (últimos 30 min) que no se hayan avisado
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val desde = fmt.format(Date(System.currentTimeMillis() - 30 * 60 * 1000L))
        val ob = get("pedidos?negocio_id=eq.$nid&estado=eq.pendiente&creado=gte.$desde&select=id,cliente_nombre,total,metodo_pago&order=creado")
        if (ob != null) {
            val a = try { JSONArray(ob) } catch (_: Exception) { null } ?: return
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                consider(o.optString("id"), o)
            }
        }
    }

    /* ---------------- Notificación ---------------- */

    private fun consider(id: String, info: JSONObject) {
        if (id.isEmpty()) return
        synchronized(notified) {
            if (!notified.add(id)) return
            if (notified.size > 200) {
                val it = notified.iterator()
                it.next()
                it.remove()
            }
        }
        // Con la app abierta suena la propia página (mismo audio): no duplicar
        if (AppState.foreground) return
        showOrder(id, info)
    }

    private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k, "")

    private fun showOrder(id: String, d: JSONObject) {
        val cliente = d.str("cliente_nombre")
        val total = if (!d.isNull("total")) d.optDouble("total") else null
        val transf = d.str("metodo_pago") == "transferencia"

        val text = buildString {
            append(if (cliente.isNotEmpty()) cliente else "Tienes un pedido nuevo")
            if (total != null) append(" · ").append(total.toLong()).append(" CUP")
        }
        val big = text + (if (transf) "\n💳 Pago por transferencia" else "") + "\nAbre la app para aceptarlo"

        val sound = Uri.parse("android.resource://$packageName/${R.raw.dueno_negocio}")
        val n = NotificationCompat.Builder(this, CH_ORDERS)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFFFFC400.toInt())
            .setContentTitle("🛎️ ¡Pedido nuevo!")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(big))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setSound(sound) // Android 7 y anterior; en 8+ manda el canal
            .setVibrate(longArrayOf(0, 400, 200, 400, 200, 600))
            .setAutoCancel(true)
            .setTimeoutAfter(30 * 60 * 1000L)
            .setContentIntent(openAppIntent(id.hashCode()))
            .build()
        try {
            NotificationManagerCompat.from(this).notify(id.hashCode(), n)
        } catch (_: SecurityException) {
            // Sin permiso de notificaciones
        }
        wakeScreen()
    }

    /** Enciende la pantalla unos segundos para que el dueño vea el pedido aunque el teléfono esté apagado. */
    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val w = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "voyya:pantalla"
            )
            w.acquire(6000)
        } catch (_: Exception) {
        }
    }

    private fun openAppIntent(req: Int): PendingIntent {
        val i = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("abrir_negocio", true)
        }
        return PendingIntent.getActivity(this, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /* ---------------- Cierre ---------------- */

    private fun shutdown() {
        running = false
        gen++
        socket?.cancel()
        pollTask?.cancel(false)
        hbTask?.cancel(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        gen++
        try { pollTask?.cancel(false); hbTask?.cancel(false) } catch (_: Exception) {}
        try { socket?.cancel() } catch (_: Exception) {}
        exec.shutdown()
        try { wl?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        super.onDestroy()
    }
}
