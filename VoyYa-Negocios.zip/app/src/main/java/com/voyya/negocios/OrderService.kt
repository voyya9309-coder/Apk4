package com.voyya.negocios

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Servicio en primer plano: mantiene abierta la conexión en tiempo real con Supabase
 * y lanza una notificación con el audio de aviso cuando llega un aviso nuevo.
 * Funciona aunque la app esté cerrada (queda una notificación fija pequeña mientras escucha).
 */
class OrderService : Service() {

    companion object {
        const val CH_SERVICE = "servicio_v1"
        const val CH_ORDERS = "pedidos_v1"
        const val NOTIF_FG = 1

        @Volatile
        var running = false

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, OrderService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, OrderService::class.java))
            } catch (_: Exception) {
            }
        }

        fun createChannels(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val fg = NotificationChannel(CH_SERVICE, "Conexión de pedidos", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Mantiene la app lista para avisarte de pedidos nuevos"
                setShowBadge(false)
            }
            nm.createNotificationChannel(fg)

            val sound = Uri.parse("android.resource://${ctx.packageName}/${R.raw.negocio}")
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val orders = NotificationChannel(CH_ORDERS, "Pedidos de tu negocio", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Aviso con sonido cuando entra un pedido nuevo en tu negocio"
                setSound(sound, attrs)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400, 200, 600)
                enableLights(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(orders)
        }
    }

    // Cliente para el WebSocket (sin límite de lectura) y otro para peticiones REST (15 s)
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)
        .build()
    private val rest = http.newBuilder().readTimeout(15, TimeUnit.SECONDS).build()

    private val exec = Executors.newSingleThreadScheduledExecutor()
    private var pollTask: ScheduledFuture<*>? = null
    private var hbTask: ScheduledFuture<*>? = null
    private var socket: WebSocket? = null
    private var gen = 0
    private var retry = 0
    private var hbRef = 100
    private var currentUser: String? = null
    private var wl: PowerManager.WakeLock? = null

    @Volatile
    private var lastMsg = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val fg = NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("¡VoyYa! Negocios")
            .setContentText("Conectado: te avisaremos de los pedidos nuevos")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent(0))
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_FG, fg, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_FG, fg)
        }

        val uid = Prefs.userId(this)
        if (uid == null) {
            shutdown()
            return START_NOT_STICKY
        }
        if (!running || uid != currentUser) {
            currentUser = uid
            running = true
            startWork()
        }
        return START_STICKY
    }

    private fun startWork() {
        synchronized(notified) { notified.clear() }
        negId = null
        if (wl == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voyya:pedidos").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
        pollTask?.cancel(false)
        hbTask?.cancel(false)
        post { connect() }
        try {
            pollTask = exec.scheduleWithFixedDelay({ safe { poll() } }, 5, 30, TimeUnit.SECONDS)
            hbTask = exec.scheduleWithFixedDelay({ safe { heartbeat() } }, 25, 25, TimeUnit.SECONDS)
        } catch (_: RejectedExecutionException) {
        }
    }

    /** Ejecuta en el hilo del servicio; si el servicio ya se apagó, ignora (evita que la app se cierre). */
    private fun post(block: () -> Unit) {
        try {
            exec.execute {
                try {
                    block()
                } catch (_: Throwable) {
                }
            }
        } catch (_: RejectedExecutionException) {
        }
    }

    private inline fun safe(block: () -> Unit) {
        try {
            block()
        } catch (_: Exception) {
        }
    }

    /* ---------------- Conexión en tiempo real (protocolo Phoenix de Supabase Realtime) ---------------- */

    private fun connect() {
        if (!running) return
        val url = Prefs.url(this) ?: return
        val key = Prefs.key(this) ?: return
        socket?.cancel()
        val myGen = ++gen
        val host = url.removePrefix("https://").trimEnd('/')
        val req = Request.Builder()
            .url("wss://$host/realtime/v1/websocket?apikey=$key&vsn=1.0.0")
            .build()
        lastMsg = System.currentTimeMillis()
        socket = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                post {
                    if (myGen != gen) return@post
                    retry = 0
                    lastMsg = System.currentTimeMillis()
                    webSocket.send(joinMessage(key))
                    safe { poll() } // recupera lo que se haya perdido mientras no había conexión
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                post { if (myGen == gen) safe { onWsMessage(text) } }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                post { if (myGen == gen) scheduleReconnect() }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                post { if (myGen == gen) scheduleReconnect() }
            }
        })
    }

    private fun scheduleReconnect() {
        if (!running) return
        gen++ // invalida eventos de la conexión anterior
        val delay = minOf(30L, 1L shl minOf(retry, 5))
        retry++
        try {
            exec.schedule({ safe { connect() } }, delay, TimeUnit.SECONDS)
        } catch (_: RejectedExecutionException) {
        }
    }

    private fun joinMessage(key: String): String {
        val change = JSONObject().put("event", "*").put("schema", "public").put("table", "pedidos")
        val config = JSONObject()
            .put("broadcast", JSONObject().put("ack", false).put("self", false))
            .put("presence", JSONObject().put("key", ""))
            .put("postgres_changes", JSONArray().put(change))
            .put("private", false)
        return JSONObject()
            .put("topic", "realtime:voyya-negocios")
            .put("event", "phx_join")
            .put("payload", JSONObject().put("config", config).put("access_token", key))
            .put("ref", "1")
            .put("join_ref", "1")
            .toString()
    }

    private fun heartbeat() {
        socket?.send(
            JSONObject()
                .put("topic", "phoenix")
                .put("event", "heartbeat")
                .put("payload", JSONObject())
                .put("ref", (hbRef++).toString())
                .toString()
        )
    }

    private fun onWsMessage(text: String) {
        lastMsg = System.currentTimeMillis()
        val j = JSONObject(text)
        when (j.optString("event")) {
            "postgres_changes" -> {
                val data = j.optJSONObject("payload")?.optJSONObject("data") ?: return
                onChange(data)
            }
            "phx_error", "phx_close" -> {
                socket?.cancel()
                scheduleReconnect()
            }
        }
    }

    @Volatile
    private var negId: String? = null

    private val notified = LinkedHashSet<String>()

    private fun onChange(data: JSONObject) {
        val rec = data.optJSONObject("record") ?: return
        val id = rec.optString("id")
        if (id.isEmpty()) return
        val mine = negId ?: return
        if (rec.optString("negocio_id") != mine) return
        if (rec.optString("estado") == "pendiente") consider(id, null)
        else NotificationManagerCompat.from(this).cancel(id.hashCode())
    }

    /* ---------------- Peticiones REST ---------------- */

    private fun get(path: String): String? {
        val url = Prefs.url(this) ?: return null
        val key = Prefs.key(this) ?: return null
        val req = Request.Builder()
            .url("$url/rest/v1/$path")
            .header("apikey", key)
            .header("Authorization", "Bearer $key")
            .build()
        return try {
            rest.newCall(req).execute().use { if (it.isSuccessful) it.body?.string() else null }
        } catch (_: Exception) {
            null
        }
    }

    private fun poll() {
        if (!running) return
        val uid = Prefs.userId(this) ?: return
        if (System.currentTimeMillis() - lastMsg > 75_000) {
            socket?.cancel()
            scheduleReconnect()
        }
        val ub = get("usuarios?id=eq.$uid&select=baneado,aprobado")
        if (ub != null) {
            val a = try { JSONArray(ub) } catch (_: Exception) { null }
            if (a != null) {
                if (a.length() == 0) { Prefs.clear(this); shutdown(); return }
                val u = a.getJSONObject(0)
                val baneado = u.optBoolean("baneado", false)
                val noAprobado = !u.isNull("aprobado") && !u.optBoolean("aprobado", true)
                if (baneado || noAprobado) { Prefs.clear(this); shutdown(); return }
            }
        }
        if (negId == null) {
            val nb = get("negocios?dueno_id=eq.$uid&select=id")
            val a = try { JSONArray(nb) } catch (_: Exception) { null }
            negId = a?.optJSONObject(0)?.optString("id")?.ifEmpty { null }
        }
        val n = negId ?: return
        val ob = get("pedidos?negocio_id=eq.$n&estado=eq.pendiente&select=id,cliente_nombre,total,items,metodo_pago&order=creado")
        if (ob != null) {
            val a = try { JSONArray(ob) } catch (_: Exception) { null } ?: return
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                consider(o.optString("id"), o)
            }
        }
    }

    /* ---------------- Notificación ---------------- */

    private fun consider(id: String, info: JSONObject?) {
        if (id.isEmpty()) return
        synchronized(notified) {
            if (!notified.add(id)) return
            if (notified.size > 200) { val it = notified.iterator(); it.next(); it.remove() }
        }
        // Con la app abierta suena la propia página (mismo audio): no duplicar
        if (AppState.foreground) return
        val d = info ?: run {
            val b = get("pedidos?id=eq.$id&select=id,cliente_nombre,total,items,metodo_pago")
            try { JSONArray(b).optJSONObject(0) } catch (_: Exception) { null }
        }
        showOrder(id, d)
    }

    private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k, "")

    private fun showOrder(id: String, d: JSONObject?) {
        val cli = d?.str("cliente_nombre").orEmpty()
        val total = if (d != null && !d.isNull("total")) d.optDouble("total") else null
        val its = d?.optJSONArray("items")
        val lista = buildString {
            if (its != null) for (i in 0 until its.length()) {
                val o = its.optJSONObject(i) ?: continue
                if (isNotEmpty()) append(", ")
                append(o.optInt("q")).append("× ").append(o.optString("n"))
            }
        }
        val pago = if (d?.str("metodo_pago") == "transferencia") "Pago: transferencia" else "Pago: efectivo"
        val text = buildString {
            if (cli.isNotEmpty()) append(cli)
            if (total != null) append(if (isNotEmpty()) " · " else "").append("${total.toLong()} CUP")
        }.ifEmpty { "Abre la app para verlo" }
        val big = text + (if (lista.isNotEmpty()) "\n$lista" else "") + "\n$pago"
        notifyNow(id.hashCode(), "🏪 ¡Nuevo pedido en tu negocio!", text, big)
    }

    private fun notifyNow(nid: Int, title: String, text: String, big: String) {
        val sound = Uri.parse("android.resource://$packageName/${R.raw.negocio}")
        val n = NotificationCompat.Builder(this, CH_ORDERS)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFFFFC400.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(big))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setSound(sound)
            .setVibrate(longArrayOf(0, 400, 200, 400, 200, 600))
            .setAutoCancel(true)
            .setTimeoutAfter(15 * 60 * 1000L)
            .setContentIntent(openAppIntent(nid))
            .build()
        try {
            NotificationManagerCompat.from(this).notify(nid, n)
        } catch (_: SecurityException) {
        }
    }

    private fun openAppIntent(req: Int): PendingIntent {
        val i = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("abrir_negocio", true)
        }
        return PendingIntent.getActivity(this, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /* ---------------- Cierre ---------------- */

    private fun shutdown() {
        running = false
        gen++
        socket?.cancel()
        pollTask?.cancel(false)
        hbTask?.cancel(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        gen++
        try { pollTask?.cancel(false); hbTask?.cancel(false) } catch (_: Exception) {}
        try { socket?.cancel() } catch (_: Exception) {}
        exec.shutdown()
        try { wl?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        super.onDestroy()
    }
}
