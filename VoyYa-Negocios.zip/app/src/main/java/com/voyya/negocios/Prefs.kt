package com.voyya.negocios

import android.content.Context

/** Sesión del dueño de negocio guardada en el teléfono para que el servicio funcione con la app cerrada. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("voyya_negocio", Context.MODE_PRIVATE)

    fun save(c: Context, userId: String, url: String, key: String) {
        sp(c).edit()
            .putString("uid", userId)
            .putString("url", url.trimEnd('/'))
            .putString("key", key)
            .apply()
    }

    fun clear(c: Context) {
        sp(c).edit().remove("uid").remove("url").remove("key").apply()
    }

    fun userId(c: Context): String? = sp(c).getString("uid", null)
    fun url(c: Context): String? = sp(c).getString("url", null)
    fun key(c: Context): String? = sp(c).getString("key", null)

    fun batteryAsked(c: Context): Boolean = sp(c).getBoolean("bat_asked", false)
    fun setBatteryAsked(c: Context) = sp(c).edit().putBoolean("bat_asked", true).apply()
}

/** Dice si la pantalla de la app está abierta (en ese caso suena la propia página, no la notificación). */
object AppState {
    @Volatile
    var foreground: Boolean = false
}
