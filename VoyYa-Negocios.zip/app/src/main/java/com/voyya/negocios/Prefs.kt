package com.voyya.negocios

import android.content.Context

/** Sesión del dueño del negocio guardada en el teléfono para que el servicio funcione con la app cerrada. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("voyya", Context.MODE_PRIVATE)

    fun save(c: Context, userId: String, url: String, key: String, comision: Float) {
        sp(c).edit()
            .putString("uid", userId)
            .putString("url", url.trimEnd('/'))
            .putString("key", key)
            .putFloat("comision", comision)
            .apply()
    }

    fun clear(c: Context) {
        sp(c).edit().remove("uid").remove("url").remove("key").remove("comision").apply()
    }

    fun userId(c: Context): String? = sp(c).getString("uid", null)
    fun url(c: Context): String? = sp(c).getString("url", null)
    fun key(c: Context): String? = sp(c).getString("key", null)
    fun comision(c: Context): Float = sp(c).getFloat("comision", 0f)

    fun muted(c: Context, k: String): Boolean = sp(c).getBoolean("mute_$k", false)
    fun setMuted(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean("mute_$k", v).apply()

    fun batteryAsked(c: Context): Boolean = sp(c).getBoolean("bat_asked", false)
    fun setBatteryAsked(c: Context) = sp(c).edit().putBoolean("bat_asked", true).apply()
}

/** Dice si la pantalla de la app está abierta (en ese caso suena la propia página, no la notificación). */
object AppState {
    @Volatile
    var foreground: Boolean = false
}
