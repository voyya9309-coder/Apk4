package com.voyya.negocios

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Al encender el teléfono (o actualizar la app) vuelve a escuchar pedidos si hay un repartidor con sesión. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Prefs.userId(context) != null) {
            OrderService.start(context)
        }
    }
}
